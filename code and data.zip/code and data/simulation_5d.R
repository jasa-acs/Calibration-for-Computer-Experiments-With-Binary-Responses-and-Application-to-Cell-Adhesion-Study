library(calibrateBinary)
library(lhs)

n.sim <- 100 # number of simulated examples

##### true function: eta #####
test_function_p <- function(X)
{
  x1 <- X[,1]
  x2 <- X[,2]
  
  x1 <- (x1-0.5)*4
  x2 <- (x2-0.5)*4
  
  fact1 <- x1
  fact2 <- exp(-x1^2 - x2^2)
  
  p <- (fact1 * fact2+1.2)/2+0.05
  
  y <- rep(NA, length(p))
  for(i in 1:length(p)) y[i] <- rbinom(1, 1, p[i])
  
  return(list(y = y, p = p))
}

##### true function: p #####
test_function_s <- function(X)
{
  x1 <- X[,1]
  x2 <- X[,2]
  x3 <- X[,3]
  x4 <- X[,4]
  x5 <- X[,5]
  
  x1 <- (x1-0.5)*4
  x2 <- (x2-0.5)*4
  
  fact1 <- x1
  fact2 <- exp(-x1^2 - x2^2)
  
  p <- (fact1 * fact2+1.2)/2+0.05 - 0.35 * (x3 - 0.3)^2 - 0.35 * (x4 - 0.5)^2 - 0.35 * (x5 - 0.7)^2 - 0.01*(x1-x2)^2

  y <- rep(NA, length(p))
  for(i in 1:length(p)) y[i] <- rbinom(1, 1, p[i])
  
  return(list(y = y, p = p))
}

##### running simulation 100 times: Table 2 #####
nN.mx <- matrix(c(150,500,250,1500), ncol = 2, byrow = T)
for(kk in 1:nrow(nN.mx)){
  theta_star.mx <- matrix(0, ncol = 3, nrow = n.sim)
  for (j in 1:n.sim){
    set.seed(j)
    n <- nN.mx[kk,1]
    xp <- maximinLHS(n = n, k = 2)
    out <- test_function_p(xp)
    yp <- out$y
    
    N <- nN.mx[kk,2]
    xs <- maximinLHS(n = N, k = 5)
    out <- test_function_s(xs)
    ys <- out$y
    
    calibrate.result <- calibrateBinary(xp, yp, xs[,1:2], xs[,3:5], ys)  
    theta_star <- calibrate.result$calibration[1,1:3]

    theta_star.mx[j,] <- theta_star
  }
  cat("L2 calibration: n =", n, ", N =", N, 
      ", mean =", round(apply(theta_star.mx, 2, mean), 4), 
      ", sd =", round(apply(theta_star.mx, 2, sd), 4)) 
  
}


