library(calibrateBinary)
library(randomForest)

n.sim <- 100 # number of simulated examples

##### true functions of phat and eta #####
p_theta <- function(x,theta) exp(exp(-0.5*x)*cos(3.5*pi*x*(0.7+theta)))/3

obj_calibration <- function(theta){
  x <- seq(0, 1, length = 1000)
  if(length(theta) > 1){
    apply(matrix(theta,ncol=1), 1, function(y) {
      sqrt(mean((exp(exp(-0.5*x)*cos(3.5*pi*x))/3 - p_theta(x, y))^2))}
      )
  }else{
    sqrt(mean((exp(exp(-0.5*x)*cos(3.5*pi*x))/3 - p_theta(x, theta))^2))
  }
} 
obj_soln <- optim(0.5, function(theta) obj_calibration(theta))
theta_true <- obj_soln$par
cat("true calibration parameter is", theta_true, "\n")

##### plot the true functions: Figrue 3 #####
par(mfrow = c(1,3))
par(mar = c(4.1,4.1,1.1,1.1))

x <- seq(0,1,length.out = 50)
eta_x <- exp(exp(-0.5*x)*cos(3.5*pi*x))/3
plot(x, eta_x, type = "n", ylab = expression(eta(x)), xlab = "x\n(a)")
lines(x, eta_x, col = 1, lty = 1, lwd = 2)
lines(x, p_theta(x,0), col = 4, lty = 5)

plot(x, eta_x, type = "n", ylab = expression(eta(x)), xlab = "x\n(b)")
lines(x, eta_x, col = 1, lty = 1, lwd = 2)
lines(x, p_theta(x,0.3), col = 4, lty = 5)

plot(x, eta_x, type = "n", ylab = expression(eta(x)), xlab = "x\n(c)")
lines(x, eta_x, col = 1, lty = 1, lwd = 2)
lines(x, p_theta(x,1), col = 4, lty = 5)

##### running simulation 100 times: Table 1 #####
# L2 calibration: n = 50, N = 400
theta_star.vt <- rep(0,n.sim)
xp <- seq(0,1,length.out = 50)
xs <- expand.grid(seq(0,1,length.out = 20),seq(0,1,length.out = 20))
for (j in 1:n.sim){
  set.seed(j)
  n <- length(xp)
  eta_p <- exp(exp(-0.5*xp)*cos(3.5*pi*xp))/3
  yp <- rep(0,n)
  for(i in 1:n) yp[i] <- rbinom(1,1, eta_p[i])
  
  N <- nrow(xs)
  p_theta <- function(x,theta) exp(exp(-0.5*x)*cos(3.5*pi*x*(0.7+theta)))/3
  
  eta_s <- p_theta(xs[,1],xs[,2])
  ys <- rep(0,N)
  for(i in 1:N) ys[i] <- rbinom(1,1, eta_s[i])
  
  calibrate.result <- calibrateBinary(xp, yp, xs[,1], xs[,2], ys) 
  theta_star <- calibrate.result$calibration[1,1]
  
  theta_star.vt[j] <- theta_star
}
cat("L2 calibration: n =", n, ", N =", N, ", mean =", mean(theta_star.vt), ", sd =", sd(theta_star.vt), "\n")  


##### plot asymptotic distribution of theta hat: Figure 4 #####
x <- seq(0, 1, 0.001)
etap <- exp(exp(-0.5*x)*cos(3.5*pi*x))/3
Dphat <- -7*pi*x*exp(exp(-0.5*x)*cos(3.5*pi*x)-x/2)*sin(3.5*pi*x)/6 # derivative of p hat
W <- mean(etap * (1-etap) * Dphat * Dphat)
V <- mean(49*pi^2*x^2/18*exp(exp(-0.5*x)*cos(3.5*pi*x)-3/2*x)*exp(exp(-0.5*x)*cos(3.5*pi*x)+x/2)*(sin(3.5*pi*x))^2)

par(mfrow = c(1,1))
par(mar = c(4.1,1.1,1.1,1.1))
plot(density(theta_star.vt), main = "", yaxt = "n",
     ylim = range(dnorm(x = x, 0.3, sd = sqrt(4*W/V/V/50))), 
     xlim = c(0,0.7), xlab = expression(theta), lwd = 2)
lines(x, dnorm(x = x, 0.3, sd = sqrt(4*W/V/V/50)), lty = 2, lwd = 2)


##### running simulation 100 times: Table 1 #####
# L2 calibration: n = 100, N = 900
theta_star.vt <- rep(0,n.sim)
xp <- seq(0,1,length.out = 100)
xs <- expand.grid(seq(0,1,length.out = 30),seq(0,1,length.out = 30))
for (j in 1:n.sim){
  set.seed(j)
  n <- length(xp)
  eta_p <- exp(exp(-0.5*xp)*cos(3.5*pi*xp))/3
  yp <- rep(0,n)
  for(i in 1:n) yp[i] <- rbinom(1,1, eta_p[i])
  
  N <- nrow(xs)
  p_theta <- function(x,theta) exp(exp(-0.5*x)*cos(3.5*pi*x*(0.7+theta)))/3
  
  eta_s <- p_theta(xs[,1],xs[,2])
  ys <- rep(0,N)
  for(i in 1:N) ys[i] <- rbinom(1,1, eta_s[i])
  
  calibrate.result <- calibrateBinary(xp, yp, xs[,1], xs[,2], ys)  
  theta_star <- calibrate.result$calibration[1,1]
  
  theta_star.vt[j] <- theta_star
}
cat("L2 calibration: n =", n, ", N =", N, ", mean =", mean(theta_star.vt), ", sd =", sd(theta_star.vt), "\n") 


##### running simulation 100 times: Table 1 #####
# Naive method: n = 50, N = 400
theta_star.vt <- rep(0,n.sim)
xp <- seq(0,1,length.out = 50)
xs <- expand.grid(seq(0,1,length.out = 20),seq(0,1,length.out = 20))
for (j in 1:n.sim){
  set.seed(j)
  n <- length(xp)
  eta_p <- exp(exp(-0.5*xp)*cos(3.5*pi*xp))/3
  yp <- rep(0,n)
  for(i in 1:n) yp[i] <- rbinom(1,1, eta_p[i])
  
  N <- nrow(xs)
  p_theta <- function(x,theta) exp(exp(-0.5*x)*cos(3.5*pi*x*(0.7+theta)))/3
  
  eta_s <- p_theta(xs[,1],xs[,2])
  ys <- rep(0,N)
  for(i in 1:N) ys[i] <- rbinom(1,1, eta_s[i])
  
  data.sim <- data.frame(xs, ys = as.factor(ys))
  rf.sim <- randomForest(ys ~ ., data = data.sim)
  opt.function <- function(theta){
    data.phy <- data.frame("Var1" = xp, "Var2" = theta)
    mean(yp != predict(rf.sim, newdata = data.phy))
  }
  theta.values <- matrix(seq(0,1,0.001), ncol = 1)
  misclass.rate <- apply(theta.values, 1, opt.function)
  min.value <- min(misclass.rate)
  if(sum(misclass.rate == min.value) > 1){
    theta_star <- theta.values[sample(which(misclass.rate == min.value),1)]
  }else{
    theta_star <- theta.values[which.min(misclass.rate)]
  }
  
  theta_star.vt[j] <- theta_star
}
cat("Naive method: n =", n, ", N =", N, ", mean =", mean(theta_star.vt), ", sd =", sd(theta_star.vt), "\n") 


##### running simulation 100 times: Table 1 #####
# Naive method: n = 100, N = 900
theta_star.vt <- rep(0,n.sim)
xp <- seq(0,1,length.out = 100)
xs <- expand.grid(seq(0,1,length.out = 30),seq(0,1,length.out = 30))
for (j in 1:n.sim){
  set.seed(j)
  n <- length(xp)
  eta_p <- exp(exp(-0.5*xp)*cos(3.5*pi*xp))/3
  yp <- rep(0,n)
  for(i in 1:n) yp[i] <- rbinom(1,1, eta_p[i])
  
  N <- nrow(xs)
  p_theta <- function(x,theta) exp(exp(-0.5*x)*cos(3.5*pi*x*(0.7+theta)))/3
  
  eta_s <- p_theta(xs[,1],xs[,2])
  ys <- rep(0,N)
  for(i in 1:N) ys[i] <- rbinom(1,1, eta_s[i])
  
  data.sim <- data.frame(xs, ys = as.factor(ys))
  rf.sim <- randomForest(ys ~ ., data = data.sim)
  opt.function <- function(theta){
    data.phy <- data.frame("Var1" = xp, "Var2" = theta)
    mean(yp != predict(rf.sim, newdata = data.phy))
  }
  theta.values <- matrix(seq(0,1,0.001), ncol = 1)
  misclass.rate <- apply(theta.values, 1, opt.function)
  min.value <- min(misclass.rate)
  if(sum(misclass.rate == min.value) > 1){
    theta_star <- theta.values[sample(which(misclass.rate == min.value),1)]
  }else{
    theta_star <- theta.values[which.min(misclass.rate)]
  }
  
  theta_star.vt[j] <- theta_star
}
cat("Naive method: n =", n, ", N =", N, ", mean =", mean(theta_star.vt), ", sd =", sd(theta_star.vt), "\n") 
